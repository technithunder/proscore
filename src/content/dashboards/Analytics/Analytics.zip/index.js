import PageHeader from './PageHeader';
import Footer from 'src/components/Footer';
import PageTitleWrapper from 'src/components/PageTitleWrapper';
import { Helmet } from 'react-helmet-async';
import Gauge from 'src/components/Gauge';
// import Conversions from './Conversions';
import TopLandingPages from './TopLandingPages';
import ActiveReferrals from './ActiveReferrals';
import PendingInvitations from './PendingInvitations';
import BounceRate from './BounceRate';
import ConversionsAlt from './ConversionsAlt';
import GaugeChartView from './GaugeChart';
import {
  Box,
  Card,
  CardHeader,
  Divider,
  Grid,
  Stack,
  Tooltip,
  Typography
} from '@mui/material';

import { buildStyles } from 'react-circular-progressbar';
import { useTranslation } from 'react-i18next';
import WoktForceTable from './WotkForce';
import LandingPages from './LandingPages';
import GaugeChartView2 from './GaugeChart2';
import GaugeChartView1 from './GaugeChart1';

const data = {
  percentage: 68,
  sales: 127,
  customers: 1.358,
  earnings: '$15,864.00'
};

function DashboardAnalytics() {
  const { t } = useTranslation();
  return (
    <>
      <Helmet>
        <title>ProscroPlus</title>
      </Helmet>
      <PageTitleWrapper>
        <PageHeader />
      </PageTitleWrapper>
      <Grid
        sx={{
          px: 3
        }}
        container
        direction="row"
        justifyContent="center"
        alignItems="stretch"
        spacing={4}
      >
        <Grid item lg={12} md={6} xs={12}>
          <Grid
            container
            spacing={4}
            direction="row"
            justifyContent="center"
            alignItems="stretch"
          >
            <Grid item sm={3} xs={12}>
              <ActiveReferrals />
            </Grid>
            <Grid item sm={3} xs={12}>
              <PendingInvitations />
            </Grid>
            <Grid item sm={3} xs={12}>
              <BounceRate />
            </Grid>
            <Grid item sm={3} xs={12}>
              <ConversionsAlt />
            </Grid>
          </Grid>
        </Grid>

        <Grid item sm={12}>
          <WoktForceTable />
        </Grid>

        <Grid item lg={12} md={6} xs={12}>
          <Grid
            container
            spacing={4}
            direction="row"
            justifyContent="center"
            alignItems="stretch"
          >
            <Grid item sm={5} xs={12}>
              <Card sx={{ minHeight: '80%' }}>
                <CardHeader title={t('Weekly Total Workforce Compliance')} />
                <Divider sx={{ mb: 2 }} />
                <Gauge
                  circleRatio={0.68}
                  styles={buildStyles({ rotation: 1 / 2 + 1 / 5.7 })}
                  value={data.percentage}
                  strokeWidth={13}
                  text={`${data.percentage}%`}
                  color="success"
                  size="xxlarge"
                />
                <Stack direction="row" justifyContent="space-around">
                  <Box sx={{ p: 2 }}>
                    <Tooltip
                      placement="top"
                      title="Total Workforce Hourse"
                      arrow
                    >
                      <Typography fontSize={10} color="text.secondary">Total Workforce Hourse</Typography>
                    </Tooltip>

                    <Typography fontSize={20} fontWeight="bold">
                      4219
                    </Typography>
                  </Box>
                  <Box sx={{ p: 2 }}>
                    <Tooltip placement="top" title="Apprentice OTJ Hours" arrow>
                      <Typography fontSize={10} color="text.secondary">Apprentice OTJ Hours</Typography>
                    </Tooltip>

                    <Typography fontSize={20} fontWeight="bold">
                      1428
                    </Typography>
                  </Box>
                  <Box sx={{ p: 2 }}>
                    <Tooltip fontSize={10} placement="top" title="Journeyman - to - Apprentice Hours" arrow>
                      <Typography color="text.secondary">Journeyman - to - Apprentice Hours</Typography>
                    </Tooltip>
                    <Typography fontSize={20} fontWeight="bold">
                      32%
                    </Typography>
                  </Box>
                </Stack>
              </Card>
            </Grid>
            <Grid item sm={7} xs={12}>
              <Card>
                <CardHeader title="Proscore Efficiency Score (PES)" />
                <Divider />
                <Grid container spacing={2}>
                  <Grid item sm={4} xs={12}>
                    <GaugeChartView />
                  </Grid>
                  <Grid item sm={4} xs={12}>
                    <GaugeChartView1 />
                  </Grid>
                  <Grid item sm={4} xs={12}>
                    <GaugeChartView2 />
                  </Grid>
                </Grid>
              </Card>
            </Grid>
          </Grid>
        </Grid>
      </Grid>

      <Box m={3}>
        <Typography mb={2} fontWeight="700" fontSize={18}>
          RAP Progression (Apprentice stats by Project)
        </Typography>
        <Grid container spacing={2}>
          <Grid item md={6} xs={12}>
            <TopLandingPages title={'Quartz solar'} />
          </Grid>
          <Grid item md={6} xs={12}>
            <LandingPages title={'Sunnyside Up'} />
          </Grid>
        </Grid>
      </Box>
      <Footer />
    </>
  );
}

export default DashboardAnalytics;
