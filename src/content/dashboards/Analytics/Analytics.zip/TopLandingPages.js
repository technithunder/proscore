import {
  CardHeader,
  Divider,
  CardContent,
  Avatar,
  Box,
  Typography,
  ListItemAvatar,
  Card,
  ListItemText,
  List,
  ListItem,
  styled
} from '@mui/material';

import { useTranslation } from 'react-i18next';
import Label from 'src/components/Label';

const AvatarLight = styled(Avatar)(
  ({ theme }) => `
      background-color: ${theme.colors.alpha.black[10]};
      color:  ${theme.colors.alpha.black[100]};
      font-weight: ${theme.typography.fontWeightBold};
      font-size: ${theme.typography.pxToRem(15)};
`
);

function TopLandingPages({ title }) {
  const { t } = useTranslation();

  return (



    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <CardHeader title={`Project Name: ${title}`} />
      <Divider />
      <CardContent>
        <List component="div" disablePadding>
          <ListItem
            sx={{
              display: { xs: 'block', sm: 'flex' }
            }}
            disableGutters
            alignItems="flex-start"
            component="div"
          >
            <ListItemAvatar>
              <AvatarLight>1</AvatarLight>
            </ListItemAvatar>

            <ListItemText
              primary="Last Week Seat Time VS Seat Time Completion"
              primaryTypographyProps={{
                variant: 'h6',
                sx: {
                  mt: 1
                },
                gutterBottom: true,
                noWrap: true
              }}
              secondaryTypographyProps={{ variant: 'h3', noWrap: true }}
              secondary={
                <Box
                  sx={{
                    mt: 1,
                    flexDirection: 'row',
                    display: 'flex'
                  }}
                >
                  <Box
                    sx={{
                      mr: 5
                    }}
                  >
                    <Typography
                      component="div"
                      variant="body2"
                      gutterBottom
                      color="text.secondary"
                    >
                      {t('Last Week Seat Time')}
                    </Typography>
                    <Box display="flex" alignItems="center">
                      <Typography
                        component="div"
                        variant="h3"
                        sx={{
                          mr: 1
                        }}
                      >
                        200
                      </Typography>
                    </Box>
                  </Box>
                  <Box>
                    <Typography
                      component="div"
                      variant="body2"
                      gutterBottom
                      color="text.secondary"
                    >
                      {t('Seat Time Completion')}
                    </Typography>
                    <Box display="flex" alignItems="center">
                      <Typography
                        component="div"
                        variant="h3"
                        sx={{
                          mr: 1
                        }}
                      >
                        198.99%
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              }
            />
          </ListItem>
          <Divider
            sx={{
              my: 1
            }}
          />
          <ListItem
            sx={{
              display: { xs: 'block', sm: 'flex' }
            }}
            disableGutters
            alignItems="flex-start"
            component="div"
          >
            <ListItemAvatar>
              <AvatarLight>2</AvatarLight>
            </ListItemAvatar>

            <ListItemText
              primary="Last Week OTJ Hours vs Work Process Completion"
              primaryTypographyProps={{
                variant: 'h6',
                sx: {
                  mt: 1
                },
                gutterBottom: true,
                noWrap: true
              }}
              secondaryTypographyProps={{ variant: 'h3', noWrap: true }}
              secondary={
                <Box
                  sx={{
                    mt: 1,
                    flexDirection: 'row',
                    display: 'flex'
                  }}
                >
                  <Box
                    sx={{
                      mr: 5
                    }}
                  >
                    <Typography
                      component="div"
                      variant="body2"
                      gutterBottom
                      color="text.secondary"
                    >
                      {t('Last week OTJ Hours')}
                    </Typography>
                    <Box display="flex" alignItems="center">
                      <Typography
                        component="div"
                        variant="h3"
                        sx={{
                          mr: 1
                        }}
                      >
                        800
                      </Typography>
                    </Box>
                  </Box>
                  <Box>
                    <Typography
                      component="div"
                      variant="body2"
                      gutterBottom
                      color="text.secondary"
                    >
                      {t('Work Process Completion')}
                    </Typography>
                    <Box display="flex" alignItems="center">
                      <Typography
                        component="div"
                        variant="h3"
                        sx={{
                          mr: 1
                        }}
                      >
                        32K
                      </Typography>
                      <Label color="success">2.5%</Label>
                    </Box>
                  </Box>
                </Box>
              }
            />
          </ListItem>
          <Divider
            sx={{
              my: 1
            }}
          />
        </List>
      </CardContent>
    </Card>
   
  );
}

export default TopLandingPages;
