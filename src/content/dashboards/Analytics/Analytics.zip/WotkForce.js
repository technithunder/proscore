import React from 'react';
import {
  Divider,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography
} from '@mui/material';
import { useTranslation } from 'react-i18next';

const data = [
  {
    postion: 'Labores',
    rate: '$16.20',
    fringe: '$3.80',
    totalHour: '$20.00',
    proposedHour: '$21.00',
    complaint: 'Yes',
    confidenceMatch: '40%'
  },
  {
    postion: 'Skid',
    rate: '$20.22',
    fringe: '$3.80',
    totalHour: '$20.00',
    proposedHour: '$21.00',
    complaint: 'Yes',
    confidenceMatch: '40%'
  },
  {
    postion: 'Pile',
    rate: '$16.20',
    fringe: '$3.80',
    totalHour: '$20.00',
    proposedHour: '$21.00',
    complaint: 'Yes',
    confidenceMatch: '40%'
  }
];

const WoktForceTable = () => {
  const { t } = useTranslation();

  return (
    <Paper>
      <Stack p={2} direction="row" justifyContent="space-between">
        <Typography fontWeight="700">
          {t('Weekly Total Workforce Compliance')}
        </Typography>
        <Stack spacing={2} direction="row">
          <Typography fontWeight="700">Working Hours: 253,440</Typography>
          <Typography fontWeight="700">Class Room Hours: 8649</Typography>
        </Stack>
      </Stack>
      <Divider />
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: '100%' }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Position</TableCell>
              <TableCell align="right">Wage rate</TableCell>
              <TableCell align="right">fringe</TableCell>
              <TableCell align="right">total hourly comp</TableCell>
              <TableCell align="right">proposed total hourly comp</TableCell>
              <TableCell align="right">complaint</TableCell>
              <TableCell align="right"><b >PW ai % confidence match</b></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((row) => (
              <TableRow
                key={row.postion}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                <TableCell component="th" scope="row">
                  {row.postion}
                </TableCell>
                <TableCell align="right">{row.rate}</TableCell>
                <TableCell align="right">{row.fringe}</TableCell>
                <TableCell align="right">{row.totalHour}</TableCell>
                <TableCell align="right">{row.proposedHour}</TableCell>
                <TableCell align="right">{row.complaint}</TableCell>
                <TableCell align="right"><b>{row.confidenceMatch}</b></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default WoktForceTable;
